from django.urls import path,include
from . import views
from rest_framework import routers

router = routers.DefaultRouter()

router.register(r'emp', views.api_view)# takes two argument raw data and view.apiviews

urlpatterns =  [
    path('',include(router.urls)),
    ]